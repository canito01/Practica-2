# crud-php-prototipo-refactorizado
Prototipo de CRUD refactorizado
